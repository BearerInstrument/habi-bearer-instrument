(* ===================================================================
   HABI Formal Safety Proof — Month 9 FINAL Deliverable
   Topic 55-24-02: High-Assurance Bearer-Instrument Logic

   Compile: coqc habi_safety.v  (Coq 8.19.2, OCaml 4.13.1)
   =================================================================== *)

Require Import Bool.
Require Import List.
Import ListNotations.
Require Import Arith.
Require Import Classical.
Require Import Extraction.
Require Import ExtrOcamlBasic.
Require Import ExtrOcamlNatInt.

Section GenericModel.
  Variable Node Bearer : Type.

  Record state := mkState {
    ledgers   : Node -> Bearer -> Prop;
    spent     : Node -> Bearer -> Prop;
    networkUp : bool
  }.

  Definition SyncedNoDoubleSpend (s : state) : Prop :=
    networkUp s = true ->
    forall b, (exists n, spent s n b) -> forall m, ~ ledgers s m b.

  Definition update_node (f : Node -> Bearer -> Prop)
                         (n : Node) (g : Bearer -> Prop) : Node -> Bearer -> Prop :=
    fun n' b => (n' = n /\ g b) \/ (n' <> n /\ f n' b).

  Definition spendLedgers (led : Node -> Bearer -> Prop)
                          (netUp : bool) (n : Node) (b : Bearer) :
                          Node -> Bearer -> Prop :=
    fun n' b' => led n' b' /\ ~ (b' = b /\ netUp = true).

  Inductive SStep : state -> state -> Prop :=
  | SStep_Disconnect : forall s,
      networkUp s = true ->
      SStep s (mkState (ledgers s) (spent s) false)
  | SStep_Replicate : forall s n1 n2 b,
      ledgers s n1 b ->
      networkUp s = true ->
      SStep s (mkState (fun n b' => (n = n2 /\ b' = b) \/ ledgers s n b')
                       (spent s) (networkUp s))
  | SStep_SpendAt : forall s n b,
      ledgers s n b ->
      networkUp s = true ->
      SStep s (mkState (spendLedgers (ledgers s) true n b)
                       (fun n' b' => spent s n' b' \/ (n' = n /\ b' = b))
                       (networkUp s))
  | SStep_SpendAt_Offline : forall s n b,
      ledgers s n b ->
      networkUp s = false ->
      SStep s (mkState (spendLedgers (ledgers s) false n b)
                       (fun n' b' => spent s n' b' \/ (n' = n /\ b' = b))
                       false)
  | SStep_SafeReconnect : forall s final_ledgers,
      networkUp s = false ->
      (forall n b, final_ledgers n b -> exists n0, ledgers s n0 b) ->
      (forall n b, final_ledgers n b -> ~ (exists n0, spent s n0 b)) ->
      (forall b n1 n2, final_ledgers n1 b -> final_ledgers n2 b -> n1 = n2) ->
      SStep s (mkState final_ledgers (spent s) true).

  Lemma spendat_offline_trivial :
    forall s n b,
      networkUp s = false ->
      ledgers s n b ->
      SyncedNoDoubleSpend
        (mkState (spendLedgers (ledgers s) false n b)
                 (update_node (spent s) n (fun b' => spent s n b' \/ b' = b))
                 false).
  Proof.
    intros s n b Hnet Hled Hup.
    unfold SyncedNoDoubleSpend in Hup.
    simpl in Hup.
    discriminate.
  Qed.

  Lemma safe_step_preserves_invariant :
    forall s s',
      SyncedNoDoubleSpend s ->
      SStep s s' ->
      SyncedNoDoubleSpend s'.
  Proof.
    intros s s' Hinv Hstep.
    destruct Hstep as
      [ s Hup
      | s n1 n2 b Hled Hup
      | s n b Hled Hup
      | s n b Hled Hdown
      | s final_ledgers Hdown Hsub Hnospent Huniq ].
    - unfold SyncedNoDoubleSpend. simpl. intros Hcontra. discriminate.
    - unfold SyncedNoDoubleSpend in *. simpl.
      intros Hup' b0 [n0 Hsp0] m Hcase.
      destruct Hcase as [[Heqm Heqb] | Hledm].
      + subst m b0.
        exact (Hinv Hup' b (ex_intro _ n0 Hsp0) n1 Hled).
      + exact (Hinv Hup' b0 (ex_intro _ n0 Hsp0) m Hledm).
    - unfold SyncedNoDoubleSpend in *. simpl.
      intros Hup' b0 [n0 Hsp0] m Hled0.
      destruct Hsp0 as [Hsp0 | [HeqN HeqB]].
      + unfold spendLedgers in Hled0.
        destruct Hled0 as [Hled0' _].
        exact (Hinv Hup' b0 (ex_intro _ n0 Hsp0) m Hled0').
      + subst b0. unfold spendLedgers in Hled0.
        destruct Hled0 as [_ Hnot].
        exact (Hnot (conj eq_refl eq_refl)).
    - unfold SyncedNoDoubleSpend. simpl. intros Hcontra. discriminate.
    - unfold SyncedNoDoubleSpend in *. simpl.
      intros Hup' b0 [n0 Hsp0] m HledFinal.
      exact (Hnospent m b0 HledFinal (ex_intro _ n0 Hsp0)).
  Qed.
End GenericModel.

Inductive Node3 := N1 | N2 | N3.
Inductive Bearer2 := b1 | b2.

Definition Node3_eq_dec (x y : Node3) : {x = y} + {x <> y}.
Proof. decide equality. Defined.
Definition Bearer2_eq_dec (x y : Bearer2) : {x = y} + {x <> y}.
Proof. decide equality. Defined.

Record state3 := mkState3 {
  ledgers3   : Node3 -> Bearer2 -> Prop;
  spent3     : Node3 -> Bearer2 -> Prop;
  networkUp3 : bool
}.

Definition SyncedNoDoubleSpend3 (s : state3) : Prop :=
  networkUp3 s = true ->
  forall b, (exists n, spent3 s n b) -> forall m, ~ ledgers3 s m b.

Definition ledger_unsafe (n : Node3) (b : Bearer2) : Prop :=
  match n, b with
  | N1, b1 => True
  | _, _  => False
  end.

Definition spent_N1_N2_b1 (n : Node3) (b : Bearer2) : Prop :=
  match n, b with
  | N1, b1 => True
  | N2, b1 => True
  | _, _   => False
  end.

Definition state_double_spend : state3 :=
  mkState3 ledger_unsafe spent_N1_N2_b1 false.

Lemma naive_reconnect_breaks_safety :
  exists s s',
    networkUp3 s = false /\ spent3 s N1 b1 /\ spent3 s N2 b1 /\
    networkUp3 s' = true /\ ~ SyncedNoDoubleSpend3 s'.
Proof.
  exists state_double_spend.
  exists (mkState3 ledger_unsafe spent_N1_N2_b1 true).
  repeat split; simpl; auto.
  unfold SyncedNoDoubleSpend3. intros H.
  specialize (H eq_refl b1).
  assert (Hex: exists n, spent_N1_N2_b1 n b1) by (exists N1; simpl; auto).
  specialize (H Hex N1). simpl in H. apply H. trivial.
Qed.

Class EqDec (A : Type) := {
  eqb    : A -> A -> bool;
  eqb_eq : forall x y, eqb x y = true <-> x = y
}.

Instance EqDec_Node3 : EqDec Node3.
Proof.
  refine {| eqb := fun x y => if Node3_eq_dec x y then true else false |}.
  intros x y. destruct (Node3_eq_dec x y); intuition; try discriminate.
Defined.

Instance EqDec_Bearer2 : EqDec Bearer2.
Proof.
  refine {| eqb := fun x y => if Bearer2_eq_dec x y then true else false |}.
  intros x y. destruct (Bearer2_eq_dec x y); intuition; try discriminate.
Defined.

Record state_exe := mkStateExe {
  ledgers_exe   : Node3 -> Bearer2 -> bool;
  spent_exe     : Node3 -> Bearer2 -> bool;
  networkUp_exe : bool
}.

Definition ledgers_exe_empty : Node3 -> Bearer2 -> bool := fun _ _ => false.

Definition update_node_exe (f : Node3 -> Bearer2 -> bool)
                           (n : Node3) (b : Bearer2) (v : bool)
                           : Node3 -> Bearer2 -> bool :=
  fun n' b' =>
    if Node3_eq_dec n' n
    then if Bearer2_eq_dec b' b then v else f n' b'
    else f n' b'.

Definition spendLedgers_exe (led : Node3 -> Bearer2 -> bool)
                            (netUp : bool) (n : Node3) (b : Bearer2)
                            : Node3 -> Bearer2 -> bool :=
  fun n' b' =>
    if Node3_eq_dec n' n then
      if Bearer2_eq_dec b' b then
        if netUp then false else led n' b'
      else led n' b'
    else led n' b'.

Definition run_conversion_day_exe (s : state_exe) : option state_exe :=
  if networkUp_exe s then None
  else
    let ds_n1n2_b1 := spent_exe s N1 b1 && spent_exe s N2 b1 in
    let ds_n1n2_b2 := spent_exe s N1 b2 && spent_exe s N2 b2 in
    let ds_n1n3_b1 := spent_exe s N1 b1 && spent_exe s N3 b1 in
    let ds_n2n3_b1 := spent_exe s N2 b1 && spent_exe s N3 b1 in
    if ds_n1n2_b1 || ds_n1n2_b2 || ds_n1n3_b1 || ds_n2n3_b1 then None
    else Some (mkStateExe (ledgers_exe s) (spent_exe s) true).

Definition check_post_barrier_safety_exe (s : state_exe) : bool :=
  negb (spent_exe s N1 b1 && spent_exe s N2 b1) &&
  negb (spent_exe s N1 b2 && spent_exe s N2 b2) &&
  negb (spent_exe s N1 b1 && spent_exe s N3 b1) &&
  negb (spent_exe s N2 b1 && spent_exe s N3 b1).

Lemma run_conversion_day_exe_preserves_safety :
  forall s s',
    run_conversion_day_exe s = Some s' ->
    check_post_barrier_safety_exe s' = true.
Proof.
  intros s s' Hrun.
  unfold run_conversion_day_exe in Hrun.
  destruct (networkUp_exe s); try discriminate.
  remember (spent_exe s N1 b1 && spent_exe s N2 b1) as ds12b1.
  remember (spent_exe s N1 b2 && spent_exe s N2 b2) as ds12b2.
  remember (spent_exe s N1 b1 && spent_exe s N3 b1) as ds13b1.
  remember (spent_exe s N2 b1 && spent_exe s N3 b1) as ds23b1.
  destruct ds12b1, ds12b2, ds13b1, ds23b1; try discriminate.
  inversion Hrun; subst; clear Hrun.
  unfold check_post_barrier_safety_exe.
  simpl.
  rewrite <- Heqds12b1, <- Heqds12b2, <- Heqds13b1, <- Heqds23b1.
  reflexivity.
Qed.

(* -----------------------------------------------------------------
   (3) Minimality / Completeness
   ----------------------------------------------------------------- *)
Definition IsSafeReconnect (R : state3 -> state3 -> Prop) : Prop :=
  forall s s',
    R s s' -> networkUp3 s = false -> networkUp3 s' = true ->
    SyncedNoDoubleSpend3 s'.
Theorem naive_reconnect_not_safe :
  ~ IsSafeReconnect
      (fun s s' => networkUp3 s = false /\ networkUp3 s' = true /\
                   ledgers3 s' = ledgers3 s /\ spent3 s' = spent3 s).
Proof.
  unfold IsSafeReconnect, not. intros H.
  assert (Hsafe := H state_double_spend
                     (mkState3 ledger_unsafe spent_N1_N2_b1 true)
                     (conj eq_refl (conj eq_refl (conj eq_refl eq_refl)))
                     eq_refl eq_refl).
  unfold SyncedNoDoubleSpend3 in Hsafe.
  specialize (Hsafe eq_refl b1).
  assert (Hex: exists n, spent_N1_N2_b1 n b1) by (exists N1; simpl; auto).
  specialize (Hsafe Hex N1). simpl in Hsafe. apply Hsafe. trivial.
Qed.
Theorem safe_reconnect_implies_invariant :
  forall R s s',
    IsSafeReconnect R ->
    R s s' ->
    networkUp3 s = false ->
    networkUp3 s' = true ->
    SyncedNoDoubleSpend3 s'.
Proof.
  intros R s s' Hsafe HR Hdown Hup.
  exact (Hsafe s s' HR Hdown Hup).
Qed.
Theorem reconnect_must_forbid_naive_double_spend :
  forall R : state3 -> state3 -> Prop,
    IsSafeReconnect R ->
    ~ R state_double_spend (mkState3 ledger_unsafe spent_N1_N2_b1 true).
Proof.
  intros R Hsafe HR.
  specialize (Hsafe state_double_spend
                     (mkState3 ledger_unsafe spent_N1_N2_b1 true)
                     HR eq_refl eq_refl).
  unfold SyncedNoDoubleSpend3 in Hsafe. simpl in Hsafe.
  specialize (Hsafe eq_refl b1).
  assert (Hex: exists n, spent_N1_N2_b1 n b1) by (exists N1; simpl; auto).
  specialize (Hsafe Hex N1). simpl in Hsafe. apply Hsafe. trivial.
Qed.

(* -----------------------------------------------------------------
   (3b) Per-link model: mirrors DIL_CRDT_PerLink_Symmetric.tla.
   PairwiseSyncedNoDoubleSpend3 is the Coq analogue of that file's
   PairwiseSyncedNoDoubleSpend -- distinct from SyncedNoDoubleSpend3
   above, which mirrors DIL_CRDT.tla's global-networkUp model instead.
   ----------------------------------------------------------------- *)

Record state3_link := mkState3Link {
  ledgers3L : Node3 -> Bearer2 -> Prop;
  spent3L   : Node3 -> Bearer2 -> Prop;
  network3  : Node3 -> Node3 -> bool
}.

Definition PairwiseSyncedNoDoubleSpend3 (s : state3_link) : Prop :=
  forall n1 n2 : Node3,
    network3 s n1 n2 = true ->
    forall b : Bearer2,
      (spent3L s n1 b \/ spent3L s n2 b) ->
      ~ ledgers3L s n1 b /\ ~ ledgers3L s n2 b.

Definition network_all_true (a b : Node3) : bool :=
  if Node3_eq_dec a b then false else true.

Definition network_N1N2_down (a b : Node3) : bool :=
  if Node3_eq_dec a N1 then
    (if Node3_eq_dec b N2 then false else network_all_true a b)
  else if Node3_eq_dec a N2 then
    (if Node3_eq_dec b N1 then false else network_all_true a b)
  else network_all_true a b.

Definition state_double_spend_link : state3_link :=
  mkState3Link ledger_unsafe spent_N1_N2_b1 network_N1N2_down.

Definition state_double_spend_link_reconnected : state3_link :=
  mkState3Link ledger_unsafe spent_N1_N2_b1 network_all_true.

Lemma network_N1N2_down_at_N1N2 : network_N1N2_down N1 N2 = false.
Proof.
  unfold network_N1N2_down.
  destruct (Node3_eq_dec N1 N1) as [_ | Hneq1].
  - destruct (Node3_eq_dec N2 N2) as [_ | Hneq2].
    + reflexivity.
    + exfalso; apply Hneq2; reflexivity.
  - exfalso; apply Hneq1; reflexivity.
Qed.

Lemma network_all_true_N1N2 : network_all_true N1 N2 = true.
Proof.
  unfold network_all_true.
  destruct (Node3_eq_dec N1 N2) as [Heq | Hneq].
  - discriminate Heq.
  - reflexivity.
Qed.

Definition naive_link_reconnect (n m : Node3) (s s' : state3_link) : Prop :=
  network3 s n m = false /\ network3 s' n m = true /\
  ledgers3L s' = ledgers3L s /\ spent3L s' = spent3L s.

Definition IsSafeReconnectLink (R : state3_link -> state3_link -> Prop) : Prop :=
  forall s s' n m,
    R s s' -> network3 s n m = false -> network3 s' n m = true ->
    PairwiseSyncedNoDoubleSpend3 s'.

Theorem naive_reconnect_link_not_safe :
  ~ IsSafeReconnectLink (naive_link_reconnect N1 N2).
Proof.
  unfold IsSafeReconnectLink, naive_link_reconnect, not.
  intros H.
  assert (Hsafe := H state_double_spend_link state_double_spend_link_reconnected N1 N2
                     (conj network_N1N2_down_at_N1N2
                        (conj network_all_true_N1N2 (conj eq_refl eq_refl)))
                     network_N1N2_down_at_N1N2 network_all_true_N1N2).
  unfold PairwiseSyncedNoDoubleSpend3 in Hsafe.
  specialize (Hsafe N1 N2 network_all_true_N1N2 b1 (or_introl I)).
  destruct Hsafe as [Hsafe1 _].
  apply Hsafe1. exact I.
Qed.

Theorem safe_reconnect_link_implies_invariant :
  forall R s s' n m,
    IsSafeReconnectLink R -> R s s' ->
    network3 s n m = false -> network3 s' n m = true ->
    PairwiseSyncedNoDoubleSpend3 s'.
Proof.
  intros R s s' n m Hsafe HR Hdown Hup.
  exact (Hsafe s s' n m HR Hdown Hup).
Qed.

Theorem reconnect_link_must_forbid_naive_double_spend :
  forall R : state3_link -> state3_link -> Prop,
    IsSafeReconnectLink R ->
    ~ R state_double_spend_link state_double_spend_link_reconnected.
Proof.
  intros R Hsafe HR.
  assert (Hp := Hsafe state_double_spend_link state_double_spend_link_reconnected N1 N2
                  HR network_N1N2_down_at_N1N2 network_all_true_N1N2).
  unfold PairwiseSyncedNoDoubleSpend3 in Hp.
  specialize (Hp N1 N2 network_all_true_N1N2 b1 (or_introl I)).
  destruct Hp as [Hp1 _].
  apply Hp1. exact I.
Qed.

(* -----------------------------------------------------------------
   (4) Extraction
   ----------------------------------------------------------------- *)

(* -----------------------------------------------------------------
   (3c) Quorum-gated Conversion Day: mirrors
   DIL_CRDT_PerLink_ConversionDay.tla's QuorumSettlementIsSafe.
   Fixes a confirmed defect -- a conflict check restricted to a
   partial participant set P can report "no conflict" while a
   genuine two-party double-spend exists outside P -- found via TLC
   on 2026-09-17 and patched in habi_node.rs the same day.
   ----------------------------------------------------------------- *)

Definition GenuineConflict (s : state3_link) (b : Bearer2) : Prop :=
  exists n1 n2 : Node3, n1 <> n2 /\ spent3L s n1 b /\ spent3L s n2 b.

(* A conflict check restricted to participant set P is "honest" if
   finding nothing within P implies nothing exists globally. *)
Definition ParticipantCheckIsHonest (P : Node3 -> Prop) : Prop :=
  forall s : state3_link,
    (forall b, ~ (exists n1 n2, P n1 /\ P n2 /\ n1 <> n2 /\
                    spent3L s n1 b /\ spent3L s n2 b))
    -> ~ (exists b, GenuineConflict s b).

(* The fixed design: P is every known node (full quorum). Honest by
   construction -- no participant can be silently excluded. *)
Theorem full_quorum_check_is_honest :
  ParticipantCheckIsHonest (fun _ : Node3 => True).
Proof.
  unfold ParticipantCheckIsHonest, GenuineConflict.
  intros s H [b [n1 [n2 [Hne [Hs1 Hs2]]]]].
  apply (H b).
  exists n1, n2.
  split. exact I.
  split. exact I.
  split. exact Hne.
  split. exact Hs1.
  exact Hs2.
Qed.

(* The original design: the caller is always in P (it includes
   itself), so the worst case -- every peer unreachable -- reduces P
   to a singleton. No singleton can ever contain two distinct nodes,
   so this check is vacuously "clean" regardless of what actually
   happened elsewhere -- the confirmed bug, made concrete. *)
Theorem singleton_participant_check_not_honest :
  forall self : Node3, ~ ParticipantCheckIsHonest (fun n => n = self).
Proof.
  intros self Hhonest.
  set (s := mkState3Link
              (fun _ _ => False)
              (fun n b => (n = N1 \/ n = N2) /\ b = b2)
              network_all_true).
  assert (Hvac : forall b, ~ (exists n1 n2, n1 = self /\ n2 = self /\
                    n1 <> n2 /\ spent3L s n1 b /\ spent3L s n2 b)).
  { intros b [n1 [n2 [H1 [H2 [Hne _]]]]]. apply Hne. rewrite H1, H2. reflexivity. }
  specialize (Hhonest s Hvac).
  apply Hhonest.
  exists b2.
  unfold GenuineConflict.
  exists N1, N2.
  repeat split;
    try discriminate;
    try reflexivity;
    try (left; reflexivity);
    try (right; reflexivity).
Qed.

(* Given honest detection (nothing found under full quorum) and a
   full burn -- remove a bearer from every node's ledger whenever any
   node genuinely spent it, leaving spent/network untouched -- the
   resulting state satisfies PairwiseSyncedNoDoubleSpend3. This holds
   independent of the post-state's network topology; the honesty
   theorem above is what guarantees the burn only ever fires when the
   detection was actually trustworthy. *)
Theorem quorum_burn_implies_invariant :
  forall s s' : state3_link,
    network3 s' = network3 s ->
    spent3L s' = spent3L s ->
    (forall n b, ledgers3L s' n b <->
       (ledgers3L s n b /\ ~ (exists m, spent3L s m b))) ->
    PairwiseSyncedNoDoubleSpend3 s'.
Proof.
  intros s s' Hnet Hspent Hledg n1 n2 Hconn b Hor.
  split.
  - intro Hheld.
    apply (Hledg n1 b) in Hheld.
    destruct Hheld as [_ Hnone].
    apply Hnone.
    rewrite Hspent in Hor.
    destruct Hor as [H1 | H2].
    + exists n1. exact H1.
    + exists n2. exact H2.
  - intro Hheld.
    apply (Hledg n2 b) in Hheld.
    destruct Hheld as [_ Hnone].
    apply Hnone.
    rewrite Hspent in Hor.
    destruct Hor as [H1 | H2].
    + exists n1. exact H1.
    + exists n2. exact H2.
Qed.
Extraction Language OCaml.
Extraction "habi_safety.ml"
  Node3 Bearer2 state_exe ledgers_exe_empty
  spendLedgers_exe run_conversion_day_exe
  check_post_barrier_safety_exe
  Node3_eq_dec Bearer2_eq_dec.
(* -----------------------------------------------------------------)
   (3) Minimality / Completeness
   ----------------------------------------------------------------- *)

